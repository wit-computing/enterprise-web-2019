import React, { Component } from 'react';

export default class SearchBox extends Component {
    onChange = (event) => {
        event.preventDefault() ;
        let newText = event.target.value.toLowerCase() ;
        this.props.handleChange(newText) ;
    };

    render() {
        return (
            <div>
                <input type="text" placeholder="Search" 
                    onChange={this.onChange} />
            </div>
        );
    }
}