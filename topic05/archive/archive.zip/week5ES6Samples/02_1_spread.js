
// Spread - A new operator ... that takes a collection
// data structure and separates it into its individual 
// values

{ 
     // Inserting arrays
     let mid = [3, 4]
     let arr = [1, 2, mid, 5, 6]
     console.log(arr)
     arr = [1, 2, ...mid, 5, 6]
     console.log(arr)
}
{
     // Copy an array
     let arr1 = ['a', 'b', 'c']
     let arr2 = arr1
     arr2.push('d')
     console.log(`1 ${arr1}`)
     arr2 = [...arr1]
     arr2.push('e')
     console.log(`2 ${arr1}`)
}
{
     // String to array
     let hi = 'hello'
     let letters = [...hi]
     console.log(`3 ${letters}`)
}
