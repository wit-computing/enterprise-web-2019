// ...OBJECT
{
    let partOfMe = {first: 'Diarmuid', address: '1 Main street'}
    let allMe = {surname: 'O Connor', partOfMe, employer: 'WIT'}
    console.log(`1 ${JSON.stringify(allMe)}`)
    allMe = { surname: 'O Connor', ...partOfMe, employer: 'WIT'}
    console.log(`2 ${JSON.stringify(allMe)}`)
}
{
    let me = { surname: 'O Connor', first: 'Diarmuid',
        address: '1 Main street', employer: 'WIT' }
    let updatedMe = { ...me, address: '2 High Street' }
    console.log(`3 ${JSON.stringify(updatedMe)}`)
}