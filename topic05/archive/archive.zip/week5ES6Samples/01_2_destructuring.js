// OBJECT destructuring
{ 
	// without
	let obj = { alpha: 100, beta: 'enterprise'}
	let alpha = obj.alpha
	let beta = obj.beta
}
{ 
	// with
	let obj = { alpha: 100, beta: 'enterprise'}
	let {alpha, beta} = obj;
	console.log(`1 ${alpha} ${beta}`)
}
{ 
    // alternative
	let obj = { alpha: 100, beta: 'enterprise'}
	let {alpha: num, beta: word} = obj;
	console.log(`2 ${num} ${word}`)
}
{ 
	let obj = { alert: 100, beta: 'enterprise', foo: 'bar' }
	let { foo: thing, beta: word} = obj
	console.log(`3 ${word} ${thing}`)
}
{ 
	// select particular property
	let obj = { alert: 100, beta: 'enterprise', foo: 'bar' }
	let { foo } = obj
	console.log(`4 ${foo} `)
}