import React, {Component} from 'react';
import { withRouter, Route } from 'react-router-dom';

class Inbox extends Component {
  render() { 
    return (
      <div>
        <h1>Inbox page</h1>
        <Messages id={this.props.match.params.userId}/>
        <div>
          <Route path={`/inbox/:userId/statistics`} component={ Stats } />
          <Route path={`/inbox/:userId/draft`} component={ Draft } />
        </div>
      </div>
     )
  }
}

export class Messages extends Component {
  render() { 
     return <h3>Messages for user: {this.props.id} </h3>
  }
}

class Stats extends Component {
  render() { 
    return  <h3>Statistical data</h3>
  }
}
   
class Draft extends Component {
  render() { 
    return  <h3>Draft emails</h3>
  }
}
export default withRouter(Inbox);   
