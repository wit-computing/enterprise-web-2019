import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Redirect, Link, Switch,
       withRouter  } from 'react-router-dom';

export default class RegisterDeclarative extends Component {
    state = {
      toHome: false
    }
    handleSubmit = (user) => {
        // save user to datastore
        this.setState({
          toHome: true
        })
    }
    render() {
      if (this.state.toHome === true) {
        return <Redirect to='/' />
      }
      return (
        <div>
          <h2>Registration Form</h2>
          <button onClick={this.handleSubmit}>Register</button>
        </div>
      )
    }
}

class BaseRegisterImperative extends Component {
    handleSubmit = (user) => {
        // save user to datastore
        this.props.history.push('/')
    }
    
    render() {
      return (
        <div>
          <h2>Registration Form</h2>
          <button onClick={this.handleSubmit}>Submit</button>
        </div>
      )
    }
}
const RegisterImperative = withRouter(BaseRegisterImperative)

class App extends React.Component {
  render() {
      return  (  
        <div>  
          <ul>
            <li><Link to="/register1">Register Here (Declarative)</Link></li>
            <li><Link to="/register2">Register Here (Imperative)</Link></li>
          </ul>  
          <h1>Home page</h1>
          <h3>Programmattic navigation demo</h3>
        </div>
        )
    }
}

class Router extends Component {
  render() { 
    return (
      <BrowserRouter>
          <Switch>
              <Route path='/register1' component={ RegisterDeclarative } />
              <Route path='/register2' component={ RegisterImperative } />
              <Route exact path='/' component={ App } />
              <Redirect from='*' to='/' />
          </Switch>
      </BrowserRouter>
    );  
  }
}

ReactDOM.render(<Router/>, 
    document.getElementById('root'))
