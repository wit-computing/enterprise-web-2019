import React, {Component } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Redirect, Switch, Link, 
        withRouter } from 'react-router-dom';

const fakeAuth = {
  isAuthenticated: false,
  authenticate(username,cb) {
    this.isAuthenticated = true
    setTimeout(cb, 100) // fake async
  },
  signout(cb) {
    this.isAuthenticated = false
    setTimeout(cb, 100) // fake async
  }
}

class Login extends Component {
  state = {
    redirectToReferrer: false,
    username: null,
  }
  login = () => {
    fakeAuth.authenticate(
      this.state.username,
      () => {
        this.setState( {redirectToReferrer: true } )
    }  )
  }
  render() {
    const { redirectToReferrer } = this.state
    const { from } = this.props.location.state || { from: { pathname: '/' } }
    if (redirectToReferrer === true) {
      return <Redirect to={from} />
    }
    return (
      <div>
        <h3>Login page</h3>
        <p>You must log in to view the page at /protected </p>
        {/* Simple web form  */}
        <button onClick={this.login}>Log in</button>
      </div>
    )
  } 
}

class AuthButton extends Component {  
  render() {   
      const { history } = this.props
      return ( 
        fakeAuth.isAuthenticated ? 
          <p>
            Welcome! <button onClick={() => {
              fakeAuth.signout(() => history.push('/'))
            }}>Sign out</button>
          </p>  : 
          <p>You are not logged in.</p>  
        )
      }
    }

const AuthButtonwithRouter = withRouter(AuthButton )

class PrivateRoute extends Component {
  render() { 
    const { component: Component, ...rest } = this.props ;
    return ( 
      <Route { ...rest} render={ (props) =>  
         fakeAuth.isAuthenticated === true ?
           <Component {...props} />  :
           <Redirect to={
            {
              pathname: '/login',
              state: { from: this.props.location }
            }
          } /> 

         } 
       />
    )
  }
}

class Public extends Component {
   render() { 
      return <h2>Public page</h2>
   }
}

class Protected extends Component {
   render() { 
      return <h2>Protected page</h2>
   }
}

class App extends Component {
  render() { 
    return  <h2>Home page</h2>
  }
}

class Router extends Component {
  render() { 
    return (
        <BrowserRouter>
        <div>  
          <AuthButtonwithRouter/>
          <div>
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/public">Public</Link></li>
              <li><Link to="/protected">Protected</Link></li>
            </ul>
          </div>
          <Switch>
              <Route path='/public' component={ Public } />
              <Route path='/login' component={ Login } />
              <Route exact path='/' component={ App } />
              <PrivateRoute path='/protected' component={ Protected } />
              <Redirect from='*' to='/' />
          </Switch>
        </div>
      </BrowserRouter>
    ) 
  }
}

ReactDOM.render(
    <Router/>, 
    document.getElementById('root')) ;

