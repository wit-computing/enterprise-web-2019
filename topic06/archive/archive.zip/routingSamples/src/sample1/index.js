import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom';

export class About extends Component {
    render() {
        return <h2>About page</h2>
    }
}

export class Inbox extends Component {
    render() {
        return  <h2>Inbox page</h2>
    }
}

class App extends Component {
    render() {
        return  <h1>Home page</h1>
    }
}

class Router extends Component {
   render() {
      return (
        <BrowserRouter>
            <Switch>
                <Route path='/about' component={ About } />
                <Route path='/inbox' component={ Inbox } />
                <Route exact path='/' component={ App } />
                <Redirect from='*' to='/' />
            </Switch>
        </BrowserRouter>
        )
    }
}

ReactDOM.render(
    <Router/>,
    document.getElementById('root')) 

