import React, {Component} from 'react';
import { withRouter } from 'react-router-dom';

class Inbox extends Component {
  render() { 
    return (
      <div>
          <h2>Inbox page</h2>
          <h3>Messages for user: {this.props.match.params.userId} </h3>
      </div>
     )
  }
}
export default withRouter(Inbox);   
