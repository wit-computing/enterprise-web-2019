import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom';
import {About} from '../sample1';
import Inbox from './inbox';

class App extends Component {
  render() { 
    return (
      <div>
          <h2>Home page</h2>
          <p>Try <a href="http://localhost:3000/inbox/1234"> this hyperlink</a>
          <span> or </span><a href="http://localhost:3000/inbox/4321"> this one.</a></p>
      </div>
    );  
  }
}

class Router extends Component {
  render() { 
    return (
      <BrowserRouter>
          <Switch>
              <Route path='/about' component={ About } />
              <Route path='/inbox/:userId' component={ Inbox } />
              <Route exact path='/' component={ App } />
              <Redirect from='*' to='/' />
          </Switch>
      </BrowserRouter>
    );  
  }
}

ReactDOM.render(<Router/>, 
    document.getElementById('root'))
