import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom';
import Inbox from './inbox';

class App extends Component {
    render() {
        return (
            <div>    
                <h1>Home page</h1>
                <h3>Alternative Route API</h3>
                <p>Using the Route render prop to pass additional data to rendered component</p>
                <p>Try <a href="http://localhost:3000/inbox/1234/statistics">User 1234</a>
                   <span> inbox and nested route with additional props.</span> </p>
                <p>Try <a href="http://localhost:3000/inbox/4321/drafts">User 4321</a>
                    <span> inbox and standard nested route method.</span> </p>
            </div>
        );
    }
}

class Router extends Component {
    render() { 
        return (
            <BrowserRouter>
                <Switch>
                    <Route path='/inbox/:userId' component={ Inbox } />
                    <Route exact path='/' component={ App } />
                    <Redirect from='*' to='/' />
                </Switch>
            </BrowserRouter>
        )
   }
}

ReactDOM.render(<Router/>,
     document.getElementById('root'))