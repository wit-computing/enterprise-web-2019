import React, {Component} from 'react';
import { withRouter, Route } from 'react-router-dom';
import {Messages} from '../sample4/inbox'

class Inbox extends Component {
  render() { 
    let bar = 'something'
    return (
      <div>
        <h2>Inbox page</h2>
        <Messages id={this.props.match.params.userId}/>
        <Route path={`/inbox/:id/statistics`} 
              render={ (props) => <Stats {...props} other={bar} /> } />
        <Route path={`/inbox/:id/drafts`} component={ Drafts}  />
      </div>
     )
  }
}

class Stats extends Component {
  render() { 
    return  <h3>Statistical data for user: 
                    {` ${this.props.match.params.id}  (${this.props.other})`}</h3>
  }
}
   
class Drafts extends Component {
  render() { 
    return  <h3>Draft emails for user {this.props.match.params.id}</h3>
  }
}
   
export default withRouter(Inbox);   
