
let me = {
	name : {
       first : 'Diarmuid',
       last : "O'Connor"
	},   
	male : true    
} ;
let her = {
	name : {
       first : 'Sheila',
       middle: 'Yvonne',
       last : "Fleming"
	},   
	male : false    
} ;
// ==================================

// console.log('---------- Function declarations -----------------') ;
// function sayHelloTo(person) {
// 	if (person.male === true) {
//        console.log('Hello Mr. ' + person.name.last ) ;
//     } else {
//        console.log('Hello Mrs. ' + person.name.last ) ;
//     }
// }
// // Calling/invoking a function
// sayHelloTo(me) ;  
// sayHelloTo(her) ;   
// ========================================

// console.log('---------- Function expressions -----------------');
// let addMiddleName = function(person, middleName) {
//     if (person.name.middle === undefined) {    
//        person.name.middle = middleName ;
//     } else { 
//        person.name.middle += ' ' + middleName ; 
//     }
// };
// addMiddleName(me,'Stephen') ;
// addMiddleName(her,'Jane') ;
// console.log(me.name) ;
// console.log(her.name) ;
// ====================================

// console.log('---------- Function return -----------------') ;
// let myWorth = {
// 	  current : [ 
//           { amount : 20.2, bank : 'Allied Irish Bank'}, 
//           { amount : 5.1, bank : 'Bank of Ireland'}  
//       ],
// 	  deposit : [{ amount : 20.2, bank : 'Trustee Savings Bank'}],
// 	  investment : []  // Empty array
// } ;
// let computeTotal = function (accounts) {
// 	let total = 0.0  ;
//     for (let type in accounts) {                              // for-in loop
//         for (let i = 0 ; i < accounts[type].length ; i++) {   // for loop
//             total += accounts[type][i].amount ;
//     	}
//     }
//     return total ;
// };
// let result = computeTotal(myWorth);
// console.log(` Total worth = ${ result } `) ;   // String template
// // ---------------------------------------
// let saluteMaker = function(male) {
//     let result = function(surname) {  
//         console.log(`Hello Mr. ${surname}`) ;
//     };
// 	if (male === false) {
//         result = function(surname) {  
//             console.log(`Hello Mrs. ${surname}`) ;
//         };
//     }
//     return result ;
// }
// let salute = saluteMaker(her.male);
// salute(her.name.last) ;  

// ===================================
 
// console.log('---------- Methods -----------------') ;
// let person = {
// 	name : { first: 'Joe', last: 'Bloggs' }, 
// 	finances : {
// 		current : [ { amount : 10.2, bank : 'Allied Irish Bank'}, 
// 		    { amount : 5.1, bank : 'Bank of Ireland'}  ],
// 		deposit : [{ amount : 10.2, bank : 'Trustee Savings Bank'}],
// 		investment : [] 
//     },   
//     computeTotal :  function() {
// 		let total = 0.0
// 	    for (let type in this.finances) {
// 	    	for (let i = 0 ; i < this.finances[type].length ; i++) {
// 	            total += this.finances[type][i].amount ;
// 	    	}
// 	    }
// 	    return total ;
// 	},
// 	addMiddleName : function(middle_name) {
// 	    (this.name.middle === undefined) ?     // Ternary operator (?:)
// 	        this.name.middle = middle_name :
// 	        this.name.middle += ' ' + middle_name ;
// 	    return this.name
//     }
// }
// console.log(`Full worth = ${person.computeTotal()}`) ;
// person.addMiddleName('Paul') ;
// console.log(person.name) ;

//==================================================

// console.log('---------- Anonymous functions -----------------') ;
// let nums = [12,22,5,28] ;
// nums.forEach( function(entry) {
//     if (entry > 20) {
//        console.log(entry) ;
//     }
//   }
// ) ;
   
// let products = [ 
//     {name: 'Product 1', price: 110}, 
//     {name: 'Product 2', price: 90 },
// 	{name: 'Product 3', price: 120 } 
// ] ;
// products.forEach( function(product) {
//     product.price = product.price - product.price * 0.1 ;
// }) ;
// products.forEach(function(e) {console.log (e)}) ;

// setTimeout( function() {console.log('After 1000 miliseconds')}, 1000) ;
// console.log('Immediately') ;

//=====================================

// console.log('---------- Constructor functions -----------------') ;
// function Customer(name, address, finances) {
//   this.name = name ;
//   this.address = address ;
//   this.finances = finances ; 
//   let sumAccounts = function(accounts) {    // Private method
// 	  let result = 0
// 	  accounts.forEach(function(account) {
// 		  result += account.amount
// 	  })
// 	  return result;
//   }
//   this.computeTotal = function () {         // Puplic method
// 	  let total = 0.0 ;
//       for (let accountGroup in this.finances) {
//           total += sumAccounts(this.finances[accountGroup])
// 	  }
//       return total ;
//   } ;
//   this.showFinances = function (address) {
//      for (let type in this.finances) {
//         let subTotal = 0 ;
//         this.finances[type].forEach(function(account) {
//             subTotal += account.amount ;
//         }) ;
//         console.log(`\t${type.toUpperCase()} = ${subTotal}` ) ;
//      }
//   } ;
//   this.updateAccount = function (account) {
//       let typeMatch = this.finances[account.type]
//       if ( typeMatch != undefined  ) {
//           this.finances[account.type].forEach(function(account) {
//               if (account.bank === account.bank) {
//                   account.amount += account.amount ;
//                   }
//               }) ;
//           } else {
//             console.log(`${this.name} does not have an account of type  ${account.type}`) ;
//           }
//         } ;
//   }  // end constructor

// let joe = new Customer ('Joe Bloggs','I Main Street', 
//     { current : [ { amount : 10.2, bank : 'Allied Irish Bank'}, 
//                   { amount : 5.1, bank : 'Bank of Ireland'}  
//                 ],
//       deposit : [{ amount : 10.2, bank : 'Trustee Savings Bank'}]
//     } 
// );
// console.log(`${joe.name} is worth ${joe.computeTotal()} million`) ;
// console.log('The breakdown is: ');
// joe.showFinances();
// joe.updateAccount( { type : 'current', bank: 'Allieb Irish Bank', amount : 12.5} ) ;
// console.log('Updated breakdown is: ');
// joe.showFinances();
// joe.updateAccount( { type : 'highrisk', bank: 'Allied Irish Bank', amount : 12.5} );