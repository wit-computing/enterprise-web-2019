/*
  Primitive data types in JS
*/
let foo1 = 5 ;
let foo2 = 'Hello' ;
let foo3 = true 
let foo4 = null 
const foo5 = 22 // Constant
console.log( foo1 + ' ' + foo2 + ' ' 
            + foo3 + ' ' + foo4) ;
foo1 = 3 ;   // Reassign; Drop let keyword.
foo2 = 10 ;  // JS is dynamically typed.
let foo6 ;
console.log (foo6) ;
