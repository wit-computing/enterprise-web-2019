// Classes have existed in JavaScript as a design pattern for some time.
// But JS does not have classes, just class-like constructor functions.
// JS uses a prototype-based inheritance system, rather than class-based 
// inheritance.
// ES6 class is mostly syntactic sugar on this design pattern.

// ES5
// constructor function
function Point(x, y) {
  this.x = x;
  this.y = y;
}
// class methods
Point.prototype.print = function() {
  console.log('(ES5 point) ' + this.x + ', ' + this.y);
}
let p1 = new Point(1,2);
p1.print() ;

// ES6
class PointES6 {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  print() {
    console.log(`(ES6 point) ${this.x}, ${this.y}`);
  }
}
let p2 = new PointES6(2,3);
p2.print();
// No HOISTING of class declarations.

