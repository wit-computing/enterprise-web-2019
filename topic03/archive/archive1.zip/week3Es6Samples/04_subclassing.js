// The new class syntax supports sub-classing using extends
// This also introduces 'super' for calling the base class 
// constructor methods.

class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  print() {
    console.log(`${this.x}, ${this.y}`);
  }
}

class Point3D extends Point {
  constructor(x, y, z) {
    super(x, y);
    this.z = z;
  }
  print() {
    console.log(`${this.x}, ${this.y}, ${this.z}`);
  }
}

let p1 = new Point3D(1,2,3)
p1.print();

// Getters
p1.x; // 1
p1.y; // 2
p1.z; // 3

console.log(p1 instanceof Point3D) // true
console.log(p1 instanceof Point) // true