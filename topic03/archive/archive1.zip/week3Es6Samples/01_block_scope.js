let func = function() {
    let foo = 2, bar = 10
    if (true) {
          let foo = 3
          let baz = 20 
          console.log(`${foo} ${bar} ${baz}`)
             // 3 10 20
    }
    for (let foo = 4; foo < 5 ; foo++) {
          console.log(`${foo} ${bar}`) // 4 10
    }
    console.log(`${foo}`)  // 2
//     console.log(`Inside function - ${baz}`)  // Reference error
}
func()
// console.log(`Outside function - ${foo}`)    // Reference error