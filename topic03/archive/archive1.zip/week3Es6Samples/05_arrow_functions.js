const people = [
    {name: 'Sheila', credit: 20 },
    {name: 'Frank', credit: 25 },
    {name: 'Paul', credit: 10 }
]

people.forEach( function(person) {
    console.log(person.name)
})

people.forEach( person => {
    console.log(person.name)
})
// {}  optional for single-line functions
people.forEach( person => 
    console.log(person.name)
)

const func = (name, credit) => 
     console.log(`${name} has ${credit} credit`)

people.forEach( 
    person => func(person.name, person.credit)
)