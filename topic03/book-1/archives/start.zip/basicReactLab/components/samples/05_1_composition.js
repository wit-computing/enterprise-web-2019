// Demonstrates component composition
import React , { Component } from 'react';

import Child1 from './05_2_child1';
import Child2 from './05_3_child2';

export default class Parent extends Component {
    render() {
        return (
            <div >
                <h1>I'm parent component</h1>
                <Child1/>
                <Child2/>
            </div>
        );
    }
}