import React , { Component } from 'react';
import '../../node_modules/bootstrap/dist/css/bootstrap.css';

export default class CourseModulesWithProps extends Component { 
    render() {
        return <h1> TODO </h1>;
    }
}